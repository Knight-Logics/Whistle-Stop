#Requires -Version 5.1
# Start Whistle Stop social bridge (hidden) — register with install-all.ps1
$ErrorActionPreference = "Stop"

$BridgeRoot = Split-Path $PSScriptRoot -Parent
$SocialRoot = Split-Path $BridgeRoot -Parent
. (Join-Path $SocialRoot "portable-env.ps1")

# Prefer portable tools\ms-playwright; fall back to local Playwright cache after drive moves
if (-not $env:PLAYWRIGHT_BROWSERS_PATH) {
    $portableBrowsers = Join-Path $SocialRoot "tools\ms-playwright"
    $userBrowsers = Join-Path $env:USERPROFILE "AppData\Local\ms-playwright"
    if (Test-Path $portableBrowsers) { $env:PLAYWRIGHT_BROWSERS_PATH = $portableBrowsers }
    elseif (Test-Path $userBrowsers) { $env:PLAYWRIGHT_BROWSERS_PATH = $userBrowsers }
}

$Port = if ($env:WS_SOCIAL_BRIDGE_PORT) { [int]$env:WS_SOCIAL_BRIDGE_PORT } else { 8787 }
$LogDir = Join-Path $BridgeRoot "logs"
$LogFile = Join-Path $LogDir "bridge-service.log"
$StdoutLog = Join-Path $LogDir "bridge.stdout.log"
$StderrLog = Join-Path $LogDir "bridge.stderr.log"
$Node = Get-PortableNode

New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

# Auth for GitHub Pages admin -> tunnel -> bridge (matches site/data/site.json passwordHash)
if (-not $env:WS_ADMIN_PASSWORD_HASH) {
    $env:WS_ADMIN_PASSWORD_HASH = "400c226817e7e87a668c1988b211de97430bf1560be7e57a5c0577a6c76c5065"
}
$env:WS_GBP_MEDIA_PUBLIC_BASE = "https://ws-social.knightlogics.com"
$env:WS_PUBLIC_TUNNEL_URL = "https://ws-social.knightlogics.com"
$env:WS_FB_PUBLISH_MODE = if ($env:WS_FB_PUBLISH_MODE) { $env:WS_FB_PUBLISH_MODE } else { "browser_groups" }
# Presentation: show Playwright Chrome windows (FB groups, LinkedIn, Nextdoor)
$env:WS_POSTER_HEADED = if ($env:WS_POSTER_HEADED) { $env:WS_POSTER_HEADED } else { "1" }

$existing = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($existing) {
    Write-Host "Whistle Stop bridge already listening on port $Port" -ForegroundColor Green
    exit 0
}

$issues = Test-PortableStack
if ($issues.Count) {
    Write-Warning ("Portable stack issues: " + ($issues -join "; "))
}

if ($Node -eq "node" -and -not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Error "Node not found. Install Node or copy Social\tools\node from flash drive."
}

"--- $(Get-Date -Format o) start-bridge ---" | Add-Content $LogFile

Start-Process $Node -ArgumentList "bridge-server.js" -WorkingDirectory $BridgeRoot -WindowStyle Hidden `
    -RedirectStandardOutput $StdoutLog -RedirectStandardError $StderrLog

$ready = $false
for ($i = 0; $i -lt 25; $i++) {
    Start-Sleep -Seconds 1
    if (Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue) {
        $ready = $true
        break
    }
}

if ($ready) {
    Write-Host "Whistle Stop bridge listening on http://127.0.0.1:$Port" -ForegroundColor Green
    Write-Host "Tunnel: https://ws-social.knightlogics.com (when cloudflared is running)" -ForegroundColor Yellow
} else {
    Write-Warning "Bridge did not start on port $Port. See: $StderrLog"
    exit 1
}
