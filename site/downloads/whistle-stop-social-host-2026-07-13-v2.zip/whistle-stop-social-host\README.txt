﻿WHISTLE STOP â€” SOCIAL HOST PACKAGE
==================================

Who this is for
  Staff with owner or editor access in the Whistle Stop admin.
  You were prompted to download this because a Playwright host was not detected.

What you get without this package (cloud fallback)
  - Facebook Page
  - X (Twitter)

What this package enables through one always-on Windows PC
  - Facebook Page + community groups
  - X (Twitter)
  - LinkedIn
  - Google Business Profile API
  - Nextdoor

Quick start
  1. Unzip anywhere (e.g. Desktop\whistle-stop-social-host)
  2. Right-click START-HOST.ps1 â†’ Run with PowerShell
     (If blocked: Unblock-File .\START-HOST.ps1)
  3. Keep the bridge + tunnel windows open and the PC awake
  4. On any device open:
     https://knight-logics.github.io/Whistle-Stop/admin.html
     Sign in â†’ Social Poster â†’ post

Requirements
  - Windows + PowerShell
  - Node.js (or portable node from Growth System tools if present)
  - cloudflared installed for the public tunnel (ws-social.knightlogics.com)
  - Playwright browsers for LinkedIn/Nextdoor (install once via Growth System / npx playwright)

Notes
  - Demo posts target Knight Logics accounts ONLY
  - Graph platforms do not need this package
  - Before a venue pitch, run TEST-SOCIAL-PREFLIGHT.ps1 -Strict on the host PC

Admin bookmark (correct URL)
  https://knight-logics.github.io/Whistle-Stop/admin.html
  (not /admin/ and not /site/admin.html)
