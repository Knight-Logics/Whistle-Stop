#Requires -Version 5.1
# Add ws-social.knightlogics.com -> Whistle Stop bridge :8787 to shared Cloudflare tunnel
$ErrorActionPreference = "Stop"

$CfConfig = Join-Path $env:USERPROFILE ".cloudflared\config.yml"
$TunnelId = "a47bf639-95e8-4256-ae17-76bdfb664402"
$TunnelName = "knightlogics-ops"
$LocalService = "http://127.0.0.1:8787"
$Hosts = @("ws-social.knightlogics.com")

if (-not (Test-Path $CfConfig)) {
    Write-Error "Cloudflare config not found: $CfConfig"
}

$content = Get-Content $CfConfig -Raw
$toAdd = @($Hosts | Where-Object { $content -notmatch [regex]::Escape($_) })
if (-not $toAdd.Count) {
    Write-Host "Tunnel ingress already includes ws-social.knightlogics.com" -ForegroundColor Green
} else {
    Write-Host "Adding to tunnel: $($toAdd -join ', ')" -ForegroundColor Cyan
    $lines = Get-Content $CfConfig
    $out = New-Object System.Collections.Generic.List[string]
    $inserted = $false
    foreach ($line in $lines) {
        if (-not $inserted -and $line -match '^\s*-\s*service:\s*http_status:404') {
            foreach ($h in $toAdd) {
                $out.Add("  - hostname: $h")
                $out.Add("    service: $LocalService")
            }
            $inserted = $true
        }
        $out.Add($line)
    }
    if (-not $inserted) { Write-Error "No catch-all rule in config.yml" }

    $backup = "$CfConfig.bak-ws-social-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    Copy-Item $CfConfig $backup
    $out | Set-Content $CfConfig -Encoding UTF8
    Write-Host "Updated $CfConfig (backup: $backup)" -ForegroundColor Green
}

$Cloudflared = "C:\Program Files (x86)\cloudflared\cloudflared.exe"
if (Test-Path $Cloudflared) {
    foreach ($h in $Hosts) {
        Write-Host "Ensuring DNS: $h" -ForegroundColor Cyan
        $prevEap = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        try {
            $dnsOut = & $Cloudflared tunnel route dns $TunnelName $h *>&1 | Out-String
            Write-Host $dnsOut.Trim()
        } finally {
            $ErrorActionPreference = $prevEap
        }
    }
    Write-Host "Restarting cloudflared to pick up ingress..." -ForegroundColor Cyan
    Get-Process cloudflared -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Seconds 2
    Start-Process $Cloudflared -ArgumentList @(
        "tunnel", "--config", $CfConfig, "run", $TunnelId
    ) -WindowStyle Hidden
    Write-Host "Cloudflare tunnel restarted." -ForegroundColor Green
} else {
    Write-Warning "cloudflared not found at $Cloudflared"
}

Write-Host ""
Write-Host "Whistle Stop remote bridge URL:" -ForegroundColor Yellow
Write-Host "  https://ws-social.knightlogics.com/health"
Write-Host ""
Write-Host "Vercel env (already set if deployed): WS_REMOTE_BRIDGE_URL=https://ws-social.knightlogics.com"
Write-Host "Next: cd Social\WhistleStop\deploy && .\install-all.ps1"
