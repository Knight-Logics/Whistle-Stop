# Whistle Stop — always-on bridge (main PC)

Lets you open **https://knight-logics.github.io/Whistle-Stop/admin.html** from any laptop/phone while this PC stays on as the Playwright host.

## Architecture

```
GitHub Pages admin (any device)
  → knightlogics.com/api/whistle-stop-social (Vercel)
  → ws-social.knightlogics.com (Cloudflare tunnel)
  → this PC :8787 (Whistle Stop bridge)
  → Social Poster / Playwright
```

No thumb drive. No script on the presentation laptop.

## One-time setup (this PC)

```powershell
cd "E:\KnightLogics-Growth-System\Social\WhistleStop\deploy"

# 1. Add ws-social to Cloudflare tunnel + DNS + restart cloudflared
.\add-ws-social-tunnel.ps1

# 2. Auto-start bridge at logon (Task Scheduler)
.\install-all.ps1
```

## Verify before Whistle Stop pitch

```powershell
Invoke-RestMethod https://ws-social.knightlogics.com/health
Invoke-RestMethod https://knightlogics.com/api/whistle-stop-social/health
# remoteBridge should be true

cd "E:\Website Audit\High Prospective Clients\Whistle-Stop"
.\TEST-SOCIAL-PREFLIGHT.ps1
```

## Requirements

- This PC **on and logged in** (Playwright sessions)
- **cloudflared** running (shared with dispatch — dispatch `start-all.ps1` or tunnel service)
- Bridge on **:8787** (Task Scheduler after `install-all.ps1`)

## Logs

- `Social\WhistleStop\logs\bridge.log`
- `Social\WhistleStop\logs\bridge.stderr.log`
- `Social\WhistleStop\logs\watchdog.log`

## Presentation day

1. On the host PC run `PRE-LEAVE-HEALTH.ps1` (Whistle-Stop repo) — all checks green
2. Confirm this PC is awake (no sleep)
3. Open admin on laptop: `https://knight-logics.github.io/Whistle-Stop/admin.html`
4. Log in with username + password (`owner` / `editor` / `staff`) → Social Media → preflight green → post

You do **not** need `START-PRESENTATION.ps1` on the laptop if this PC is the host.
Laptop-as-host alternative: `START-HOST.ps1` + guide at `/downloads/social-host.html`.
