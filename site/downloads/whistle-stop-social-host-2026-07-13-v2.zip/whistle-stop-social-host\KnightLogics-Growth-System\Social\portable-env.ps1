# Portable paths for flash-drive demo (any drive letter).
$socialRoot = $PSScriptRoot
$toolsRoot  = Join-Path $socialRoot "tools"

$script:PortableNode = Join-Path $toolsRoot "node\node.exe"
$script:PortablePython = Join-Path $toolsRoot "python312\python.exe"
$script:PlaywrightBrowsers = Join-Path $toolsRoot "ms-playwright"

if (Test-Path $script:PlaywrightBrowsers) {
    $env:PLAYWRIGHT_BROWSERS_PATH = $script:PlaywrightBrowsers
}
elseif (-not $env:PLAYWRIGHT_BROWSERS_PATH) {
    $userBrowsers = Join-Path $env:USERPROFILE "AppData\Local\ms-playwright"
    if (Test-Path $userBrowsers) {
        $env:PLAYWRIGHT_BROWSERS_PATH = $userBrowsers
    }
}

function Get-PortableNode {
    if (Test-Path $script:PortableNode) { return $script:PortableNode }
    return "node"
}

function Test-PortableStack {
    $issues = @()
    # Portable tools are optional when system Node/Python are installed
    if (-not (Test-Path $script:PortableNode) -and -not (Get-Command node -ErrorAction SilentlyContinue)) {
        $issues += "Missing tools\node\node.exe (and no system node)"
    }
    $venvPy = Join-Path $socialRoot "Social-Media-Manager\.venv\Scripts\python.exe"
    if (-not (Test-Path $venvPy)) { $issues += "Missing Social-Media-Manager\.venv" }
    $browsersOk = (Test-Path $script:PlaywrightBrowsers) -or (
        $env:PLAYWRIGHT_BROWSERS_PATH -and (Test-Path $env:PLAYWRIGHT_BROWSERS_PATH)
    )
    if (-not $browsersOk) { $issues += "Missing tools\ms-playwright (and no PLAYWRIGHT_BROWSERS_PATH)" }
    return $issues
}
