#Requires -Version 5.1
$Cloudflared = "C:\Program Files (x86)\cloudflared\cloudflared.exe"
$Config = Join-Path $env:USERPROFILE ".cloudflared\config.yml"
$LocalEnv = Join-Path $PSScriptRoot ".env.cloudflare.local"

if (Test-Path $LocalEnv) {
    Get-Content $LocalEnv | ForEach-Object {
        if ($_ -match '^\s*#' -or $_ -notmatch '=') { return }
        $k, $v = $_.Split('=', 2)
        Set-Item -Path "env:$($k.Trim())" -Value $v.Trim()
    }
}

if (-not (Test-Path $Config)) {
    Write-Error "Missing $Config - run .\setup-tunnel.ps1 -Create first"
}

Write-Host "Starting Cloudflare tunnel (Ctrl+C to stop)..."
Write-Host "Routes: ops.knightlogics.com to :5050, mail.knightlogics.com to :5100"
& $Cloudflared tunnel --config $Config run
