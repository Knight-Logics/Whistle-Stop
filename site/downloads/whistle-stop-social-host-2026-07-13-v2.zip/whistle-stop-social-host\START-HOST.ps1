﻿# Whistle Stop Social Host â€” packaged launcher
$ErrorActionPreference = "Stop"
$here = $PSScriptRoot
$nestedGrowth = Join-Path $here "KnightLogics-Growth-System"
if (Test-Path (Join-Path $nestedGrowth "Social\WhistleStop\run_bridge.ps1")) {
    $env:KL_GROWTH_ROOT = $nestedGrowth
}

Write-Host ""
Write-Host "=== Whistle Stop Social Host (package) ===" -ForegroundColor Cyan
Write-Host "Unzipped at: $here" -ForegroundColor DarkGray
Write-Host "Growth root: $env:KL_GROWTH_ROOT" -ForegroundColor DarkGray
Write-Host "Admin: https://knight-logics.github.io/Whistle-Stop/admin.html" -ForegroundColor DarkGray
Write-Host ""

$presentation = Join-Path $here "START-PRESENTATION.ps1"
if (-not (Test-Path $presentation)) {
    Write-Host "Missing START-PRESENTATION.ps1 in this package." -ForegroundColor Red
    exit 1
}
& $presentation @args
