# Whistle Stop — Social Media Manager

Cross-post composer for **Whistle Stop Grill & Bar** staff admin, backed by the Knight Logics social posting stack for demos until client credentials are onboarded.

## Architecture

```
Whistle Stop admin (browser)
    → https://ws-social.knightlogics.com (Cloudflare tunnel)
        → bridge-server.js (always-on Social Host)
            → poster/bridge_cli.py (Playwright engine)
                → Facebook, X, LinkedIn, GBP, Nextdoor
                   (Knight Logics demo accounts only)
```

**Why the Social Host?** The Whistle Stop site is static (GitHub Pages). Playwright sessions and API credentials cannot run in the browser. One always-on Windows PC runs the host; staff can use the admin from any device through its HTTPS tunnel.

## Demo mode (current)

Whistle Stop does not have social credentials yet. Platform checkboxes in admin map to **Knight Logics** poster accounts:

| Whistle Stop platform | Demo posts via |
|----------------------|----------------|
| Facebook | `fb_kl` — Knight Logics Page |
| X (Twitter) | `x_kl` — @KnightLogics |
| LinkedIn | `li_kl` — Knight Logics company page via Playwright |
| Instagram | Not wired (Meta API separate) |
| Google Business Profile | `gbp_kl` — Knight Logics listing via GBP API |
| Nextdoor | `nd_kl` — Knight Logics page via Playwright |
| Instagram / TikTok / YouTube | Not connected |

When Whistle Stop credentials exist, update `platforms.json` `productionAccountId` fields and set `demoMode: false` in `data/social-manager.json`.

## Google Business Profile — limitations

The Knight Logics GBP integration is active for the demo account. Whistle Stop's own listing still requires its OAuth authorization:

| Capability | API support |
|------------|-------------|
| Standard update posts | Yes — `accounts.locations.localPosts.create` |
| Event posts | Yes |
| Offer posts | Yes |
| Product posts | **No** — dashboard only |
| Video in posts | **No** — upload manually in GBP dashboard |
| Multiple photos | Limited (typically one hero image per post) |

**Other constraints:**
- OAuth scope: `https://www.googleapis.com/auth/business.manage`
- Path: `POST .../v4/accounts/{accountId}/locations/{locationId}/localPosts`
- Rate limits: ~300 QPM API-wide; **10 edits/min per profile** (not increaseable)
- Posts expire (~7 days for updates; events follow event dates)

**Current bridge behavior:** demo posts publish to the allowlisted Knight Logics GBP location. Phase 2 swaps in Whistle Stop's OAuth/location after authorization. The manual queue remains only as a fallback.

## Quick start (demo)

1. Ensure Knight Logics poster sessions exist (`Social-Media-Manager/poster/sessions/`).
2. From this folder:
   ```powershell
   .\run_bridge.ps1
   ```
3. Open Whistle Stop admin → **Social Media** tab.
4. Click **Test all 5 — no post** and confirm every route is green.
5. Compose, select platforms, click **Post now** only when a real demo post is intended.

Bridge health: `http://127.0.0.1:8787/health`

## Logging & troubleshooting

| Resource | Location |
|----------|----------|
| **Log file** | `WhistleStop/logs/bridge.log` |
| **Live log API** | `http://127.0.0.1:8787/api/logs` |
| **Post payloads** | `WhistleStop/logs/payloads/` (temp JSON per post) |

### `spawn ENAMETOOLONG`

This was caused by passing **base64 image data on the Windows command line** (limit ~8K chars). Fixed: posts now use a **payload JSON file** instead. **Restart the bridge** after updating:

```powershell
# Stop old bridge (Ctrl+C in its window, or kill port 8787)
.\run_bridge.ps1
```

**Quick test:** post **text only** first (no photo). Then try with a photo.

### Sessions not ready

If any platform shows **Needs login** in admin:

```powershell
cd E:\KnightLogics-Growth-System\Social\Social-Media-Manager
.\run_poster.ps1
# Use login helper in Streamlit for facebook + x_kl sessions
```

Check readiness: `http://127.0.0.1:8787/api/preflight` → `readyForFullLiveTest: true`, then open `/api/dry-run` to prove all five routes without posting.

## Files

| File | Purpose |
|------|---------|
| `bridge-server.js` | HTTP API (CORS-enabled for local admin) |
| `platforms.json` | Platform catalog + demo/production mapping |
| `gbp_manual_queue.json` | Manual GBP fallback only |
| `post_history.json` | Bridge-side post log |
| `run_bridge.ps1` | Launcher |

## Roadmap

1. **Now** — Admin UI + bridge + demo posting (KL accounts)
2. **Client onboarding** — Whistle Stop FB/IG Meta tokens, X API, GBP OAuth
3. **Instagram** — Meta Content Publishing API (requires FB page linkage)
4. **Scheduling** — queue JSON + Task Scheduler like existing runners
