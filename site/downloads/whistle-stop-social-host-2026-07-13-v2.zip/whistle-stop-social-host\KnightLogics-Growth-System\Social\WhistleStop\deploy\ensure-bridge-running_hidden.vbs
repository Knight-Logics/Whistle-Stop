Option Explicit
Dim shell
Dim command
Set shell = CreateObject("WScript.Shell")
command = "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File ""E:\KnightLogics-Growth-System\Social\WhistleStop\deploy\ensure-bridge-running.ps1"""
WScript.Quit shell.Run(command, 0, True)
