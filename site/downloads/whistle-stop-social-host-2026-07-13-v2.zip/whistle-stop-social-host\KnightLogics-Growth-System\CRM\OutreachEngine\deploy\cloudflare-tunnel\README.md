# Free cloud ops — Cloudflare Tunnel (no VPS)

Use your **existing Cloudflare account** (Zero Trust is free) to expose OutreachEngine and Email Agent from this PC to:

- `https://ops.knightlogics.com` → `127.0.0.1:5050`
- `https://mail.knightlogics.com` → `127.0.0.1:5100`
- `https://poster.knightlogics.com` → `127.0.0.1:8501` (Social Poster / Streamlit)
- `https://social.knightlogics.com` → `127.0.0.1:8500` (Social Ops / Streamlit)

Knight Command on Vercel: `KL_OUTREACH_URL`, `KL_EMAIL_AGENT_URL`; optional `KL_SOCIAL_POSTER_URL`, `KL_SOCIAL_OPS_URL` for Overview health probes. Admin also falls back to the poster/social hostnames on HTTPS when env vars are unset.

**Cost: $0.** No VPS, no Railway, no new subscriptions.

## Tradeoff (be honest)

The tunnel runs on **this computer**. Remote access and scheduled sends work when this PC is on and the tunnel + services are running (same as today’s Task Scheduler model). If the PC is off, the cloud admin tabs cannot reach ops — but you are not paying for a server.

## Prerequisites

- [x] `cloudflared` installed (`C:\Program Files (x86)\cloudflared\cloudflared.exe`)
- [ ] Cloudflare account with access to **knightlogics.com** (add the zone if needed — free plan)
- [ ] OutreachEngine + Email Agent running locally (`python app.py`, Email Agent on 5100)
- [ ] Vercel env: `KL_OUTREACH_URL`, `KL_EMAIL_AGENT_URL`, `KL_ADMIN_SECRET` (already set)

## One-time setup (~10 minutes)

### 1. Log in to Cloudflare (browser)

```powershell
cd E:\KnightLogics-Growth-System\CRM\OutreachEngine\deploy\cloudflare-tunnel
.\setup-tunnel.ps1
```

Or manually:

```powershell
& "C:\Program Files (x86)\cloudflared\cloudflared.exe" tunnel login
```

Pick the **knightlogics.com** zone when prompted.

### 2. Create the tunnel

```powershell
.\setup-tunnel.ps1 -Create
```

This creates tunnel `knightlogics-ops`, writes `%USERPROFILE%\.cloudflared\config.yml`, and prints the **CNAME target** for DNS.

### 3. DNS records

Your apex DNS is on **Namecheap** (`registrar-servers.com`). You do **not** need to move the whole domain off Namecheap.

In Namecheap → Advanced DNS for `knightlogics.com`, add:

| Host | Type | Value |
|------|------|--------|
| `ops` | CNAME | `<tunnel-id>.cfargotunnel.com` (from setup script) |
| `mail` | CNAME | `<tunnel-id>.cfargotunnel.com` (same target) |

**Or**, if `knightlogics.com` is already in Cloudflare DNS, run:

```powershell
.\setup-tunnel.ps1 -RouteDns
```

### 4. Start the tunnel

```powershell
.\run-tunnel.ps1
```

Keep this window open, **or** install as a Windows service (starts on boot):

```powershell
.\install-tunnel-service.ps1
```

### 5. Test

1. Start Outreach: `cd CRM\OutreachEngine && python app.py`
2. Start Email Agent (or use Outreach’s service ensure)
3. Open `https://ops.knightlogics.com/api/ops-health` (should return JSON)
4. Open `https://knightlogics.com/admin` from your phone → Outreach CRM tab should load

## Auth

When `KL_OPS_SECRET` or `KL_ADMIN_SECRET` is set in `CRM\OutreachEngine\.env`, APIs require the same token Knight Command sends via embed. Local dev without the env var stays open on localhost.

## What this is NOT

- **Cloudflare Workers** — cannot run Python/Flask/SQLite schedulers (wrong tool)
- **VPS replacement when PC is off** — for that you need always-on hardware (old PC at home still $0 hosting) or paid cloud

## Troubleshooting

| Issue | Fix |
|-------|-----|
| 502 from ops subdomain | Outreach not running on :5050 |
| Tunnel not connected | Run `run-tunnel.ps1` or check Windows service |
| Admin embed 401 | Match `KL_ADMIN_SECRET` on Vercel and local `.env` |
| DNS not resolving | Wait 5–15 min after CNAME; verify Namecheap host is `ops` not `ops.knightlogics.com` |
