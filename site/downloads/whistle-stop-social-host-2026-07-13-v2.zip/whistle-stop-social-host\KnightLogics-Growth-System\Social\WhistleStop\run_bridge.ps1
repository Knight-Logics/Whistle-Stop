# Whistle Stop Social Bridge launcher (portable — any drive letter)
$socialRoot = Split-Path $PSScriptRoot -Parent
. (Join-Path $socialRoot "portable-env.ps1")

$root = $PSScriptRoot
$port = if ($env:WS_SOCIAL_BRIDGE_PORT) { $env:WS_SOCIAL_BRIDGE_PORT } else { 8787 }

Write-Host "=== Whistle Stop Social Bridge ===" -ForegroundColor Cyan
Write-Host "Social root: $socialRoot"
if ($env:PLAYWRIGHT_BROWSERS_PATH) {
    Write-Host "Playwright browsers: $env:PLAYWRIGHT_BROWSERS_PATH" -ForegroundColor DarkGray
}
else {
    Write-Host "WARNING: PLAYWRIGHT_BROWSERS_PATH not set — run from flash drive or install tools\ms-playwright" -ForegroundColor Yellow
}
Write-Host "Port: $port"
Write-Host ""

$existing = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
if ($existing) {
    $ownPid = ($existing | Select-Object -First 1).OwningProcess
    Write-Host "Port $port in use (PID $ownPid). Stop it first or set WS_SOCIAL_BRIDGE_PORT." -ForegroundColor Yellow
}

Set-Location $root
Write-Host "Logs: $root\logs\bridge.log" -ForegroundColor DarkGray

$node = Get-PortableNode
& $node bridge-server.js
