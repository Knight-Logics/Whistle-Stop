"use strict";

/** Hard allowlist — Whistle Stop pitch posts Knight Logics accounts ONLY. */
const DEMO_SCOPE = "knight_logics_only";

const ALLOWED_DEMO_ACCOUNT_IDS = Object.freeze([
  "fb_kl",
  "x_kl",
  "gbp_kl",
  "li_kl",
  "nd_kl",
]);

const ALLOWED_GBP_LOCATION_IDS = Object.freeze({
  gbp_kl: "1248159491432428151",
});

const TARGET_MANIFEST = Object.freeze({
  fb_kl: {
    label: "Knight Logics Facebook Page",
    platform: "facebook",
    note: "Playwright page + community group share (when bridge/tunnel running)",
  },
  x_kl: {
    label: "@KnightLogics",
    platform: "x",
    note: "X API",
  },
  gbp_kl: {
    label: "Knight Logics Google Business Profile",
    platform: "gbp",
    locationId: ALLOWED_GBP_LOCATION_IDS.gbp_kl,
    note: "GBP API — Knight Logics listing ONLY",
  },
  li_kl: {
    label: "Knight Logics LinkedIn company page",
    platform: "linkedin",
    note: "Playwright (presentation bridge required)",
  },
  nd_kl: {
    label: "Knight Logics Nextdoor page",
    platform: "nextdoor",
    note: "Playwright (presentation bridge required)",
  },
});

function isAllowedAccountId(accountId) {
  return ALLOWED_DEMO_ACCOUNT_IDS.includes(String(accountId || "").trim());
}

function filterAccountIds(accountIds) {
  const ids = [...new Set((accountIds || []).map((id) => String(id).trim()).filter(Boolean))];
  const blocked = ids.filter((id) => !isAllowedAccountId(id));
  if (blocked.length) {
    throw new Error(
      `BLOCKED: Whistle Stop demo is Knight Logics only. Refusing account(s): ${blocked.join(", ")}. ` +
        `Allowed: ${ALLOWED_DEMO_ACCOUNT_IDS.join(", ")}`
    );
  }
  return ids;
}

function facebookPublishMode() {
  const mode = String(process.env.WS_FB_PUBLISH_MODE || "browser_groups").trim().toLowerCase();
  return mode === "api" ? "api" : "browser_groups";
}

function buildTargetManifest(accountIds) {
  return filterAccountIds(accountIds).map((id) => ({
    accountId: id,
    ...(TARGET_MANIFEST[id] || { label: id, platform: "unknown" }),
    allowed: true,
  }));
}

module.exports = {
  DEMO_SCOPE,
  ALLOWED_DEMO_ACCOUNT_IDS,
  ALLOWED_GBP_LOCATION_IDS,
  TARGET_MANIFEST,
  isAllowedAccountId,
  filterAccountIds,
  facebookPublishMode,
  buildTargetManifest,
};
