#Requires -Version 5.1
param(
    [switch] $Create,
    [switch] $RouteDns,
    [switch] $LoginOnly
)

$ErrorActionPreference = "Stop"
$Cloudflared = "C:\Program Files (x86)\cloudflared\cloudflared.exe"
if (-not (Test-Path $Cloudflared)) {
    Write-Error "cloudflared not found. Install from https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/"
}

$TunnelName = "knightlogics-ops"
$CfDir = Join-Path $env:USERPROFILE ".cloudflared"
$OpsHost = "ops.knightlogics.com"
$MailHost = "mail.knightlogics.com"
$PosterHost = "poster.knightlogics.com"
$SocialHost = "social.knightlogics.com"
$WsSocialHost = "ws-social.knightlogics.com"
$LocalEnv = Join-Path $PSScriptRoot ".env.cloudflare.local"

function Write-Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }

function Import-CloudflareEnv {
    if (-not (Test-Path $LocalEnv)) { return $false }
    Get-Content $LocalEnv | ForEach-Object {
        if ($_ -match '^\s*#' -or $_ -notmatch '=') { return }
        $k, $v = $_.Split('=', 2)
        Set-Item -Path "env:$($k.Trim())" -Value $v.Trim()
    }
    return [bool]$env:CLOUDFLARE_API_TOKEN -and [bool]$env:CLOUDFLARE_ACCOUNT_ID
}

function Invoke-Cloudflared {
    param([Parameter(ValueFromRemainingArguments = $true)][string[]] $Args)
    & $Cloudflared @Args
}

if ($LoginOnly -or (-not $Create -and -not $RouteDns)) {
    Write-Step "Opening Cloudflare login (pick knightlogics.com zone)"
    & $Cloudflared tunnel login
    if (-not $Create) {
        Write-Host "`nNext: .\setup-tunnel.ps1 -Create"
        exit 0
    }
}

if ($Create) {
    New-Item -ItemType Directory -Path $CfDir -Force | Out-Null
    $useApi = Import-CloudflareEnv
    if ($useApi) {
        Write-Step "Using Cloudflare API token from .env.cloudflare.local"
    } elseif (-not (Test-Path (Join-Path $CfDir "cert.pem"))) {
        Write-Step "No Cloudflare cert yet — logging in first"
        Write-Host "Complete login in the browser window, then return here."
        & $Cloudflared tunnel login
        if (-not (Test-Path (Join-Path $CfDir "cert.pem"))) {
            Write-Error "Cloudflare login did not complete. Add .env.cloudflare.local or authorize in browser."
        }
    }

    Write-Step "Creating tunnel '$TunnelName'"
    $createOut = Invoke-Cloudflared tunnel create $TunnelName 2>&1 | Out-String
    Write-Host $createOut

    $listJson = Invoke-Cloudflared tunnel list --output json 2>&1 | Out-String
    $tunnels = $listJson | ConvertFrom-Json
    $tunnel = $tunnels | Where-Object { $_.name -eq $TunnelName } | Select-Object -First 1
    if (-not $tunnel) {
        Write-Error "Could not find tunnel '$TunnelName' after create. Run: cloudflared tunnel list"
    }
    $tunnelId = $tunnel.id
    Write-Host "Tunnel ID: $tunnelId"

    $credFile = Join-Path $CfDir "$tunnelId.json"
    if (-not (Test-Path $credFile)) {
        Write-Warning "Expected credentials at $credFile — check tunnel create output."
    }

    $configPath = Join-Path $CfDir "config.yml"
    @"
tunnel: $tunnelId
credentials-file: $credFile

ingress:
  - hostname: $OpsHost
    service: http://127.0.0.1:5050
  - hostname: $MailHost
    service: http://127.0.0.1:5100
  - hostname: $PosterHost
    service: http://127.0.0.1:8501
  - hostname: $SocialHost
    service: http://127.0.0.1:8500
  - hostname: $WsSocialHost
    service: http://127.0.0.1:8787
  - service: http_status:404
"@ | Set-Content -Path $configPath -Encoding UTF8

    Write-Step "Wrote $configPath"
    Write-Host @"

DNS (Namecheap Advanced DNS — add two CNAME records):
  Host: ops   -> ${tunnelId}.cfargotunnel.com
  Host: mail  -> ${tunnelId}.cfargotunnel.com

If the zone is in Cloudflare DNS instead, run:
  .\setup-tunnel.ps1 -RouteDns

Then start the tunnel:
  .\run-tunnel.ps1

"@
}

if ($RouteDns) {
    Import-CloudflareEnv | Out-Null
    Write-Step "Routing DNS via Cloudflare (zone must be on Cloudflare DNS)"
    Invoke-Cloudflared tunnel route dns $TunnelName $OpsHost
    Invoke-Cloudflared tunnel route dns $TunnelName $MailHost
    Invoke-Cloudflared tunnel route dns $TunnelName $PosterHost
    Invoke-Cloudflared tunnel route dns $TunnelName $SocialHost
    Invoke-Cloudflared tunnel route dns $TunnelName $WsSocialHost
    Write-Host "DNS routes added for $OpsHost, $MailHost, $PosterHost, $SocialHost, and $WsSocialHost"
}
