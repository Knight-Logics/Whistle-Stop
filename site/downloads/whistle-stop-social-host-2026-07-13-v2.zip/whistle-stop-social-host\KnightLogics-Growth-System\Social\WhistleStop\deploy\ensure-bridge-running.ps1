#Requires -Version 5.1
# Idempotent: start Whistle Stop bridge if port 8787 is not listening;
# also verify Cloudflare tunnel health and log when remote is down.
$ErrorActionPreference = "Stop"

$Port = if ($env:WS_SOCIAL_BRIDGE_PORT) { [int]$env:WS_SOCIAL_BRIDGE_PORT } else { 8787 }
$LogDir = Join-Path (Split-Path $PSScriptRoot -Parent) "logs"
$LogFile = Join-Path $LogDir "watchdog.log"
$TunnelUrl = if ($env:WS_REMOTE_BRIDGE_URL) { $env:WS_REMOTE_BRIDGE_URL.TrimEnd("/") } else { "https://ws-social.knightlogics.com" }
$CloudHealth = "https://knightlogics.com/api/whistle-stop-social/health"

New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

function Write-Watch([string]$Message) {
    "$(Get-Date -Format o) $Message" | Add-Content $LogFile
}

$bridgeUp = [bool](Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)
if (-not $bridgeUp) {
    Write-Watch "port $Port down - starting Whistle Stop bridge"
    & (Join-Path $PSScriptRoot "start-bridge.ps1")
} else {
    Write-Watch "port $Port ok"
}

# Tunnel / cloudflared check (does not auto-restart cloudflared service - logs only + optional start script)
$tunnelOk = $false
try {
    $h = Invoke-RestMethod -Uri "$TunnelUrl/health" -TimeoutSec 12
    $tunnelOk = [bool]$h.ok
} catch {
    $tunnelOk = $false
}

if (-not $tunnelOk) {
    Write-Watch "tunnel health FAIL ($TunnelUrl) - ensure cloudflared is running"
    $cloudflared = Get-Process -Name cloudflared -ErrorAction SilentlyContinue
    if (-not $cloudflared) {
        $runTunnel = "E:\KnightLogics-Growth-System\CRM\OutreachEngine\deploy\cloudflare-tunnel\run-tunnel.ps1"
        if (Test-Path $runTunnel) {
            Write-Watch "cloudflared not running - launching run-tunnel.ps1"
            Start-Process powershell -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $runTunnel -WindowStyle Minimized
        } else {
            Write-Watch "cloudflared missing and run-tunnel.ps1 not found"
        }
    }
} else {
    Write-Watch "tunnel health ok"
}

try {
    $c = Invoke-RestMethod -Uri $CloudHealth -TimeoutSec 15
    if ($c.remoteBridge) {
        Write-Watch "cloud remoteBridge=true"
    } else {
        Write-Watch "cloud remoteBridge=false (Vercel cannot see tunnel - browser-direct or Graph-only until fixed)"
    }
} catch {
    Write-Watch "cloud health check failed: $($_.Exception.Message)"
}
