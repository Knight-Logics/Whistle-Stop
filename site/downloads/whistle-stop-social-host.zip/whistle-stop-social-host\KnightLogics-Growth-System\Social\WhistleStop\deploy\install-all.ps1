#Requires -Version 5.1
# Register Task Scheduler jobs so Whistle Stop bridge runs at logon/boot (main PC stays on).
# Does NOT require Cursor. Pair with add-ws-social-tunnel.ps1 for Cloudflare ingress.
$ErrorActionPreference = "Stop"

$DeployDir = $PSScriptRoot
$StartBridge = Join-Path $DeployDir "start-bridge.ps1"
$Ensure = Join-Path $DeployDir "ensure-bridge-running.ps1"
$MainTask = "WhistleStopSocialBridge"
$WatchTask = "WhistleStopSocialBridgeWatchdog"

function Register-BridgeTask {
    param(
        [string]$Name,
        [string]$ScriptPath,
        [object[]]$Triggers,
        [switch]$Hidden
    )
    $action = New-ScheduledTaskAction -Execute "powershell.exe" `
        -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`"" `
        -WorkingDirectory $DeployDir

    $settings = New-ScheduledTaskSettingsSet `
        -AllowStartIfOnBatteries `
        -DontStopIfGoingOnBatteries `
        -StartWhenAvailable `
        -ExecutionTimeLimit (New-TimeSpan -Minutes 15) `
        -MultipleInstances IgnoreNew

    if ($Hidden) { $settings.Hidden = $true }

    Register-ScheduledTask -TaskName $Name -Action $action -Trigger $Triggers -Settings $settings -Force | Out-Null
}

$logonTrigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$bootTrigger = New-ScheduledTaskTrigger -AtStartup
$bootTrigger.Delay = "PT2M"
Register-BridgeTask -Name $MainTask -ScriptPath $StartBridge -Triggers @($logonTrigger, $bootTrigger)

$watchWrapper = Join-Path $DeployDir "ensure-bridge-running_hidden.vbs"
@(
    "Option Explicit"
    "Dim shell"
    "Set shell = CreateObject(""WScript.Shell"")"
    "shell.Run ""powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File """"""$Ensure"""""""", 0, True"
) | Set-Content $watchWrapper -Encoding ASCII

schtasks /Create /TN $WatchTask /TR "wscript.exe //B //Nologo `"$watchWrapper`"" /SC MINUTE /MO 15 /F | Out-Null

Write-Host "Registered scheduled tasks:" -ForegroundColor Green
Write-Host "  $MainTask  — Whistle Stop bridge at logon and ~2 min after boot"
Write-Host "  $WatchTask — every 15 min: restarts bridge if :8787 down; checks tunnel/cloudflared"
Write-Host ""
Write-Host "Ensure tunnel has ws-social (run once as admin if needed):" -ForegroundColor Yellow
Write-Host "  .\add-ws-social-tunnel.ps1"
Write-Host ""
Write-Host "Starting bridge now..." -ForegroundColor Cyan
& $StartBridge
