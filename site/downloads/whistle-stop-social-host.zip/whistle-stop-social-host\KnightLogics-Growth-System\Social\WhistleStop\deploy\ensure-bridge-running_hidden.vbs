Option Explicit
Dim shell
Set shell = CreateObject("WScript.Shell")
shell.Run "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File """E:\KnightLogics-Growth-System\Social\WhistleStop\deploy\ensure-bridge-running.ps1"""", 0, True
