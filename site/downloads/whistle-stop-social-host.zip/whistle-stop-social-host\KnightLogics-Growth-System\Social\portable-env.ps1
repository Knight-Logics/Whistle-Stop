# Portable paths for flash-drive demo (any drive letter).
$socialRoot = $PSScriptRoot
$toolsRoot  = Join-Path $socialRoot "tools"

$script:PortableNode = Join-Path $toolsRoot "node\node.exe"
$script:PortablePython = Join-Path $toolsRoot "python312\python.exe"
$script:PlaywrightBrowsers = Join-Path $toolsRoot "ms-playwright"

if (Test-Path $script:PlaywrightBrowsers) {
    $env:PLAYWRIGHT_BROWSERS_PATH = $script:PlaywrightBrowsers
}

function Get-PortableNode {
    if (Test-Path $script:PortableNode) { return $script:PortableNode }
    return "node"
}

function Test-PortableStack {
    $issues = @()
    if (-not (Test-Path $script:PortableNode)) { $issues += "Missing tools\node\node.exe" }
    if (-not (Test-Path $script:PortablePython)) { $issues += "Missing tools\python312\python.exe" }
    $venvPy = Join-Path $socialRoot "Social-Media-Manager\.venv\Scripts\python.exe"
    if (-not (Test-Path $venvPy)) { $issues += "Missing Social-Media-Manager\.venv" }
    if (-not (Test-Path $script:PlaywrightBrowsers)) { $issues += "Missing tools\ms-playwright" }
    return $issues
}
