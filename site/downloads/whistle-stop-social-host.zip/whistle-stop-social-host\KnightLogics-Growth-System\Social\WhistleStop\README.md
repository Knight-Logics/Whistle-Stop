# Whistle Stop — Social Media Manager

Cross-post composer for **Whistle Stop Grill & Bar** staff admin, backed by the Knight Logics social posting stack for demos until client credentials are onboarded.

## Architecture

```
Whistle Stop admin (browser)
    → POST http://127.0.0.1:8787/api/post
        → bridge-server.js (local only)
            → poster/bridge_cli.py (Playwright engine)
                → X, Facebook, LinkedIn (Knight Logics demo accounts)
            → gbp_manual_queue.json (GBP — not API-automated yet)
```

**Why local bridge?** The Whistle Stop site is static (GitHub Pages). Playwright sessions and API secrets cannot run in the browser. A small local server on the venue PC (or your demo laptop) handles real posts.

## Demo mode (current)

Whistle Stop does not have social credentials yet. Platform checkboxes in admin map to **Knight Logics** poster accounts:

| Whistle Stop platform | Demo posts via |
|----------------------|----------------|
| Facebook | `fb_kl` — Knight Logics Page |
| X (Twitter) | `x_kl` — @KnightLogics |
| LinkedIn | `li_kl` — paused until access restored |
| Instagram | Not wired (Meta API separate) |
| Google Business Profile | Manual queue + copy-paste helper |
| TikTok / YouTube / Nextdoor | Shown in UI; not connected |

When Whistle Stop credentials exist, update `platforms.json` `productionAccountId` fields and set `demoMode: false` in `data/social-manager.json`.

## Google Business Profile — limitations

**Not implemented in Knight Logics Social today.** GBP requires a new integration:

| Capability | API support |
|------------|-------------|
| Standard update posts | Yes — `accounts.locations.localPosts.create` |
| Event posts | Yes |
| Offer posts | Yes |
| Product posts | **No** — dashboard only |
| Video in posts | **No** — upload manually in GBP dashboard |
| Multiple photos | Limited (typically one hero image per post) |

**Other constraints:**
- OAuth scope: `https://www.googleapis.com/auth/business.manage`
- Path: `POST .../v4/accounts/{accountId}/locations/{locationId}/localPosts`
- Rate limits: ~300 QPM API-wide; **10 edits/min per profile** (not increaseable)
- Posts expire (~7 days for updates; events follow event dates)

**Current bridge behavior:** GBP selections are saved to `gbp_manual_queue.json` with formatted copy for staff to paste into [Google Business Profile Manager](https://business.google.com/). Phase 2: wire OAuth + `localPosts.create` once Whistle Stop grants access.

## Quick start (demo)

1. Ensure Knight Logics poster sessions exist (`Social-Media-Manager/poster/sessions/`).
2. From this folder:
   ```powershell
   .\run_bridge.ps1
   ```
3. Open Whistle Stop admin → **Social Media** tab.
4. Compose, select platforms, click **Post now**.

Bridge health: `http://127.0.0.1:8787/health`

## Logging & troubleshooting

| Resource | Location |
|----------|----------|
| **Log file** | `WhistleStop/logs/bridge.log` |
| **Live log API** | `http://127.0.0.1:8787/api/logs` |
| **Post payloads** | `WhistleStop/logs/payloads/` (temp JSON per post) |

### `spawn ENAMETOOLONG`

This was caused by passing **base64 image data on the Windows command line** (limit ~8K chars). Fixed: posts now use a **payload JSON file** instead. **Restart the bridge** after updating:

```powershell
# Stop old bridge (Ctrl+C in its window, or kill port 8787)
.\run_bridge.ps1
```

**Quick test:** post **text only** first (no photo). Then try with a photo.

### Sessions not ready

If Facebook/X show **Needs login** in admin:

```powershell
cd E:\KnightLogics-Growth-System\Social\Social-Media-Manager
.\run_poster.ps1
# Use login helper in Streamlit for facebook + x_kl sessions
```

Check readiness: `http://127.0.0.1:8787/api/platforms` → `sessionReady: true` for `facebook` and `x`.

## Files

| File | Purpose |
|------|---------|
| `bridge-server.js` | HTTP API (CORS-enabled for local admin) |
| `platforms.json` | Platform catalog + demo/production mapping |
| `gbp_manual_queue.json` | Pending GBP posts for manual publish |
| `post_history.json` | Bridge-side post log |
| `run_bridge.ps1` | Launcher |

## Roadmap

1. **Now** — Admin UI + bridge + demo posting (KL accounts)
2. **Client onboarding** — Whistle Stop FB/IG Meta tokens, X API, GBP OAuth
3. **GBP API runner** — `GBP-Runner/` mirroring X-Runner pattern
4. **Instagram** — Meta Content Publishing API (requires FB page linkage)
5. **Scheduling** — queue JSON + Task Scheduler like existing runners
