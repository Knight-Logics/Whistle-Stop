# Whistle Stop — Social Media Manager

Cross-post composer for **Whistle Stop Grill & Bar** staff admin, backed by the full Knight Logics social posting stack for pitch demos until client credentials are onboarded.

## Architecture

```
Whistle Stop admin (browser)
    → POST http://127.0.0.1:8787/api/post
        → bridge-server.js (local only)
            → poster/bridge_cli.py (Knight Logics poster engine)
                → Facebook, X, LinkedIn, Nextdoor (Playwright + API)
                → Google Business Profile (OAuth localPosts API)
```

**Why local bridge?** The Whistle Stop site is static (GitHub Pages). Playwright sessions and API secrets cannot run in the browser. A small local server on your demo laptop handles real posts.

## Demo mode (current)

Whistle Stop does not have social credentials yet. Platform checkboxes map to **all connected Knight Logics accounts**:

| Whistle Stop platform | Demo posts via |
|----------------------|----------------|
| Facebook | `fb_kl`, `fb_kg`, `fb_st`, `fb_fw` |
| X (Twitter) | `x_kl`, `x_kg`, `x_st`, `x_fw` |
| LinkedIn | `li_kl`, `li_kg`, `li_st`, `li_fw` |
| Nextdoor | `nd_kl`, `nd_kg`, `nd_st`, `nd_fw` |
| Google Business Profile | `gbp_kl`, `gbp_kg`, `gbp_st`, `gbp_fw` via **GBP API** (not manual queue) |
| Instagram | Not wired (Meta API separate) |
| TikTok / YouTube | Not connected |

When Whistle Stop credentials exist, update `platforms.json` `productionAccountId` fields and set `demoMode: false` in `data/social-manager.json`.

## Google Business Profile

Posts use the Knight Logics **GBP OAuth + localPosts API** (`poster/gbp_api.py`).

- OAuth: `GBP_OAUTH_CLIENT_ID`, `GBP_OAUTH_CLIENT_SECRET`, `GBP_REFRESH_TOKEN` in `~/.copilot-secrets/accounts.env`
- Photos require a **public URL** Google can fetch — the Whistle Stop admin passes `gbpSourceUrl` (demo: GitHub Pages gallery image)
- Videos and product posts: dashboard only, not API

## Quick start (pitch demo)

From the Whistle Stop repo:

```powershell
.\START-DEMO.ps1
```

Or manually:

1. Ensure Knight Logics poster sessions + GBP OAuth are configured.
2. From this folder:
   ```powershell
   .\run_bridge.ps1
   ```
3. Serve Whistle Stop site: `cd site && python -m http.server 8080`
4. Open `http://127.0.0.1:8080/admin.html` → **Social Media** tab → **Load pitch demo** → **Post now**.

Bridge health: `http://127.0.0.1:8787/health`

## Files

| File | Purpose |
|------|---------|
| `bridge-server.js` | HTTP API (CORS-enabled for local admin) |
| `platforms.json` | Platform catalog + multi-account demo mapping |
| `post_history.json` | Bridge-side post log |
| `run_bridge.ps1` | Launcher |
