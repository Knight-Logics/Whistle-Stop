﻿WHISTLE STOP â€” SOCIAL HOST PACKAGE
==================================

Who this is for
  Staff with owner or editor access in the Whistle Stop admin.
  You were prompted to download this because a Playwright host was not detected.

What you get without this package (cloud only)
  - Facebook Page
  - X (Twitter)
  - Google Business Profile

What this package enables (Playwright on THIS PC)
  - LinkedIn
  - Nextdoor
  - Facebook community groups

Quick start
  1. Unzip anywhere (e.g. Desktop\whistle-stop-social-host)
  2. Right-click START-HOST.ps1 â†’ Run with PowerShell
     (If blocked: Unblock-File .\START-HOST.ps1)
  3. Keep the bridge + tunnel windows open and the PC awake
  4. On any device open:
     https://knight-logics.github.io/Whistle-Stop/admin.html
     Sign in â†’ Social Poster â†’ post

Requirements
  - Windows + PowerShell
  - Node.js (or portable node from Growth System tools if present)
  - cloudflared installed for the public tunnel (ws-social.knightlogics.com)
  - Playwright browsers for LinkedIn/Nextdoor (install once via Growth System / npx playwright)

Notes
  - Demo posts target Knight Logics accounts ONLY
  - Graph platforms do not need this package
  - Before a venue pitch, run PRE-LEAVE-HEALTH.ps1 on the host PC

Admin bookmark (correct URL)
  https://knight-logics.github.io/Whistle-Stop/admin.html
  (not /admin/ and not /site/admin.html)
