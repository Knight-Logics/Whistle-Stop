/**
 * Whistle Stop Social Bridge — local HTTP API for staff admin posting.
 * Run: node bridge-server.js   (or run_bridge.ps1)
 *
 * Logs: WhistleStop/logs/bridge.log
 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { spawn } = require("child_process");
const demoScope = require("./demo-scope");

const PORT = Number(process.env.WS_SOCIAL_BRIDGE_PORT || 8787);
const ROOT = __dirname;
const SOCIAL_ROOT = path.join(ROOT, "..");
const SMM_ROOT = path.join(SOCIAL_ROOT, "Social-Media-Manager");
const PYTHON = path.join(SMM_ROOT, ".venv", "Scripts", "python.exe");
const BRIDGE_CLI = path.join(SMM_ROOT, "poster", "bridge_cli.py");
const PLAYWRIGHT_BROWSERS = path.join(SOCIAL_ROOT, "tools", "ms-playwright");
const LOG_DIR = path.join(ROOT, "logs");
const LOG_PATH = path.join(LOG_DIR, "bridge.log");

const PLATFORMS_PATH = path.join(ROOT, "platforms.json");
const HISTORY_PATH = path.join(ROOT, "post_history.json");
const GBP_QUEUE_PATH = path.join(ROOT, "gbp_manual_queue.json");
const GBP_MEDIA_DIR = path.join(ROOT, "gbp-queue-media");

fs.mkdirSync(LOG_DIR, { recursive: true });
fs.mkdirSync(GBP_MEDIA_DIR, { recursive: true });

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return fallback;
  }
}

function writeJson(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");
}

function appendLog(level, message, extra) {
  const line = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    message,
    ...(extra || {}),
  });
  try {
    fs.appendFileSync(LOG_PATH, line + os.EOL, "utf8");
  } catch {
    /* ignore log write failures */
  }
  const prefix = level === "error" ? "ERROR" : level === "warn" ? "WARN" : "INFO";
  console.log(`[${prefix}] ${message}`, extra ? extra : "");
}

function loadPlatforms() {
  return readJson(PLATFORMS_PATH, { platforms: [] });
}

function appendHistory(entry) {
  const history = readJson(HISTORY_PATH, []);
  history.unshift(entry);
  writeJson(HISTORY_PATH, history.slice(0, 200));
}

function appendGbpQueue(entry) {
  const queue = readJson(GBP_QUEUE_PATH, []);
  queue.unshift(entry);
  writeJson(GBP_QUEUE_PATH, queue.slice(0, 100));
}

function saveGbpQueueMedia(queueId, mediaB64) {
  if (!mediaB64 || typeof mediaB64 !== "string") return null;
  const match = mediaB64.match(/^data:((?:image|video)\/[a-z0-9.+-]+);base64,(.+)$/i);
  if (!match) return null;
  const mime = match[1].toLowerCase();
  const extByMime = {
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "video/mp4": "mp4",
    "video/quicktime": "mov",
    "video/webm": "webm",
    "video/x-m4v": "m4v",
  };
  const ext = extByMime[mime] || (mime.startsWith("video/") ? "mp4" : "jpg");
  const buf = Buffer.from(match[2], "base64");
  if (!buf.length) return null;
  const filename = `${queueId}.${ext}`;
  fs.writeFileSync(path.join(GBP_MEDIA_DIR, filename), buf);
  return { filename, mime, bytes: buf.length, kind: mime.startsWith("video/") ? "video" : mime === "image/gif" ? "gif" : "image" };
}

const PLAYWRIGHT_PLATFORMS = new Set(["linkedin", "nextdoor"]);

function gbpMediaPublicBase() {
  return (
    process.env.WS_GBP_MEDIA_PUBLIC_BASE ||
    process.env.WS_PUBLIC_TUNNEL_URL ||
    process.env.WS_REMOTE_BRIDGE_URL ||
    "https://ws-social.knightlogics.com"
  )
    .trim()
    .replace(/\/$/, "");
}

async function publishGbpMediaFromBase64(mediaB64) {
  const meta = saveGbpQueueMedia(`post_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`, mediaB64);
  if (!meta || meta.kind === "video") return null;
  if (meta.mime === "image/webp" || meta.mime === "image/gif") {
    try {
      const sharp = require("sharp");
      const jpgName = meta.filename.replace(/\.[^.]+$/, ".jpg");
      const srcPath = path.join(GBP_MEDIA_DIR, meta.filename);
      const jpgPath = path.join(GBP_MEDIA_DIR, jpgName);
      await sharp(srcPath).jpeg({ quality: 88 }).toFile(jpgPath);
      try {
        fs.unlinkSync(srcPath);
      } catch {
        /* ignore */
      }
      meta.filename = jpgName;
      meta.mime = "image/jpeg";
    } catch {
      appendLog("warn", "gbp webp/gif convert skipped", { file: meta.filename });
    }
  }
  const base = gbpMediaPublicBase();
  return { url: `${base}/api/gbp/media/${meta.filename}`, filename: meta.filename, mime: meta.mime };
}

async function resolveGbpSourceUrlForPost(body) {
  const explicit = String(body.gbpSourceUrl || "").trim();
  if (explicit && /^https?:\/\//i.test(explicit) && !/\.webp(\?|$)/i.test(explicit)) {
    return explicit;
  }
  const platforms = Array.isArray(body.platforms) ? body.platforms : [];
  if (!platforms.includes("gbp") || !body.mediaBase64) return explicit;
  const published = await publishGbpMediaFromBase64(body.mediaBase64);
  return published?.url || explicit;
}

function sha256(text) {
  return crypto.createHash("sha256").update(String(text), "utf8").digest("hex");
}

function timingSafeEqualString(a, b) {
  const left = Buffer.from(String(a || ""), "utf8");
  const right = Buffer.from(String(b || ""), "utf8");
  if (left.length !== right.length) return false;
  return crypto.timingSafeEqual(left, right);
}

function authorizePost(body, req) {
  const apiKey = process.env.WS_SOCIAL_API_KEY || "";
  const headerKey = req.headers["x-ws-social-key"] || req.headers["X-WS-Social-Key"] || "";
  if (apiKey && headerKey && timingSafeEqualString(headerKey, apiKey)) {
    return { ok: true, method: "api-key" };
  }
  const expectedHash = process.env.WS_ADMIN_PASSWORD_HASH || "";
  const sessionHash = typeof body?.adminSessionHash === "string" ? body.adminSessionHash : "";
  if (expectedHash && sessionHash) {
    if (timingSafeEqualString(sessionHash, expectedHash)) {
      return { ok: true, method: "admin-session" };
    }
    return { ok: false, error: "Admin session expired. Log in again." };
  }
  const password = typeof body?.adminPassword === "string" ? body.adminPassword : "";
  if (expectedHash && password) {
    if (password.length > 256) return { ok: false, error: "Admin password is incorrect." };
    if (timingSafeEqualString(sha256(password), expectedHash)) {
      return { ok: true, method: "admin-password" };
    }
    return { ok: false, error: "Admin password is incorrect." };
  }
  if (!apiKey && !expectedHash) return { ok: true, method: "open-local" };
  return {
    ok: false,
    error: "Not authorized. Sign into Whistle Stop admin or configure WS_SOCIAL_API_KEY / WS_ADMIN_PASSWORD_HASH.",
  };
}

function cors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-WS-Social-Key, X-WS-Admin-Hash");
}

function sendJson(res, status, body) {
  cors(res);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
      if (raw.length > 12 * 1024 * 1024) {
        reject(new Error("Payload too large"));
        req.destroy();
      }
    });
    req.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error("Invalid JSON body"));
      }
    });
    req.on("error", reject);
  });
}

function writePayloadFile(payload) {
  const dir = path.join(LOG_DIR, "payloads");
  fs.mkdirSync(dir, { recursive: true });
  const filePath = path.join(dir, `post_${Date.now()}.json`);
  fs.writeFileSync(filePath, JSON.stringify(payload), "utf8");
  return filePath;
}

function posterChildEnv() {
  const env = { ...process.env };
  if (!env.PLAYWRIGHT_BROWSERS_PATH && fs.existsSync(PLAYWRIGHT_BROWSERS)) {
    env.PLAYWRIGHT_BROWSERS_PATH = PLAYWRIGHT_BROWSERS;
  }
  return env;
}

function runPython(args) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(PYTHON)) {
      reject(new Error(`Python venv not found at ${PYTHON}. Set up Social-Media-Manager .venv first.`));
      return;
    }
    const childEnv = posterChildEnv();
    if (!childEnv.PLAYWRIGHT_BROWSERS_PATH) {
      reject(
        new Error(
          `Playwright browsers not found. Expected folder: ${PLAYWRIGHT_BROWSERS}\n` +
            "Copy tools\\ms-playwright from the flash drive, or run: playwright install chromium",
        ),
      );
      return;
    }
    appendLog("info", "spawn python", {
      args: args.map((a) => (a.length > 120 ? `${a.slice(0, 80)}…[${a.length} chars]` : a)),
      playwrightBrowsers: childEnv.PLAYWRIGHT_BROWSERS_PATH,
    });
    const proc = spawn(PYTHON, [BRIDGE_CLI, ...args], {
      cwd: SMM_ROOT,
      windowsHide: true,
      env: childEnv,
    });
    let stdout = "";
    let stderr = "";
    proc.on("error", (err) => {
      appendLog("error", "spawn failed", { error: err.message, code: err.code });
      reject(err);
    });
    proc.stdout.on("data", (d) => (stdout += d));
    proc.stderr.on("data", (d) => (stderr += d));
    proc.on("close", (code) => {
      if (code !== 0) {
        appendLog("error", "python exit", { code, stderr: stderr.trim().slice(0, 2000) });
        reject(new Error(stderr.trim() || `bridge_cli exited ${code}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout || "[]"));
      } catch {
        appendLog("error", "invalid cli json", { stdout: stdout.slice(0, 500) });
        reject(new Error(`Invalid CLI output: ${stdout.slice(0, 300)}`));
      }
    });
  });
}

function runPythonPost(payload) {
  const payloadFile = writePayloadFile({
    text: payload.text,
    accounts: payload.accounts,
    mediaBase64: payload.mediaBase64 || "",
    gbpSourceUrl: payload.gbpSourceUrl || "",
    fbPublishMode: payload.fbPublishMode || demoScope.facebookPublishMode(),
  });
  return runPython(["post", "--payload-file", payloadFile]);
}

function accountIdsForPlatform(plat) {
  if (Array.isArray(plat.demoAccountIds) && plat.demoAccountIds.length) {
    return plat.demoAccountIds;
  }
  return plat.demoAccountId ? [plat.demoAccountId] : [];
}

function allDemoAccountIds(catalog) {
  const ids = [];
  for (const plat of catalog.platforms || []) {
    ids.push(...accountIdsForPlatform(plat));
  }
  return [...new Set(ids)];
}

function resolveDemoAccounts(platformIds) {
  const catalog = loadPlatforms();
  const accounts = [];
  const meta = [];
  for (const pid of platformIds) {
    const plat = catalog.platforms.find((p) => p.id === pid);
    if (!plat) {
      meta.push({ platform: pid, status: "error", error: "Unknown platform" });
      continue;
    }
    const ids = accountIdsForPlatform(plat);
    if (!ids.length) {
      if (!plat.posterSupported) {
        meta.push({
          platform: pid,
          status: "not_wired",
          label: plat.label,
          error: plat.limitation || "Platform not connected in bridge",
        });
      } else {
        meta.push({
          platform: pid,
          status: "not_wired",
          label: plat.label,
          error: plat.limitation || "No demo accounts configured",
        });
      }
      continue;
    }
    if (plat.status === "paused" && ids.length === 1) {
      meta.push({
        platform: pid,
        status: "skipped",
        label: plat.label,
        accountId: ids[0],
        error: plat.limitation || "Paused",
      });
      continue;
    }
    for (const accountId of ids) {
      if (!demoScope.isAllowedAccountId(accountId)) {
        meta.push({
          platform: pid,
          status: "blocked",
          label: plat.label,
          accountId,
          error: `Account ${accountId} is not in the Knight Logics demo allowlist.`,
        });
        continue;
      }
      accounts.push(accountId);
      meta.push({
        platform: pid,
        status: "pending",
        label: plat.label,
        accountId,
        demo: true,
      });
    }
  }
  return { accounts: demoScope.filterAccountIds([...new Set(accounts)]), meta };
}

async function handlePost(body) {
  const text = String(body.text || "").trim();
  const platforms = Array.isArray(body.platforms) ? body.platforms : [];
  const mediaB64 = body.mediaBase64 || "";

  if (!text) throw new Error("Post text is required");
  if (!platforms.length) throw new Error("Select at least one platform");

  appendLog("info", "post request", {
    platforms,
    textLen: text.length,
    hasMedia: Boolean(mediaB64),
    mediaLen: mediaB64 ? mediaB64.length : 0,
  });

  const { accounts, meta } = resolveDemoAccounts(platforms);
  const results = [];

  const gbpSourceUrl = await resolveGbpSourceUrlForPost(body);
  const fbPublishMode = demoScope.facebookPublishMode();

  if (body.dryRun) {
    const targets = demoScope.buildTargetManifest(accounts);
    appendLog("info", "dry run", { platforms, accounts, fbPublishMode });
    return {
      ok: true,
      dryRun: true,
      demoScope: demoScope.DEMO_SCOPE,
      facebookMode: fbPublishMode,
      targets,
      meta,
      gbpSourceUrl: gbpSourceUrl || null,
    };
  }

  if (accounts.length) {
    const posterResults = await runPythonPost({
      text,
      accounts,
      mediaBase64: mediaB64,
      gbpSourceUrl,
      fbPublishMode,
    });
    appendLog("info", "poster results", { count: posterResults.length });
    for (const r of posterResults) {
      const plat = meta.find((m) => m.accountId === r.account_id);
      const accountLabel = r.label || plat?.label;
      results.push({
        platform: plat?.platform || r.platform || "unknown",
        label: accountLabel,
        accountId: r.account_id,
        status: r.status === "ok" ? "ok" : r.status === "skipped" ? "skipped" : "error",
        error: r.error,
        message: r.note || r.message,
        method: r.method,
        runId: r.run_id,
        sharedGroups: r.shared_groups,
        demo: true,
      });
    }
  }

  for (const m of meta) {
    if (m.status !== "not_wired") continue;
    results.push({
      platform: m.platform,
      label: m.label,
      status: "not_wired",
      error: m.error,
    });
  }

  const entry = {
    id: `post_${Date.now()}`,
    createdAt: new Date().toISOString(),
    text: text.slice(0, 500),
    platforms,
    demoMode: true,
    results,
  };
  appendHistory(entry);
  appendLog("info", "post complete", {
    results: results.map((r) => ({
      platform: r.platform,
      status: r.status,
      accountId: r.accountId,
      method: r.method,
      runId: r.runId,
    })),
  });

  return { ok: true, entry, results, demoScope: demoScope.DEMO_SCOPE, facebookMode: fbPublishMode };
}

async function handlePreflight() {
  const catalog = loadPlatforms();
  const accountIds = demoScope.filterAccountIds(allDemoAccountIds(catalog));
  const fbMode = demoScope.facebookPublishMode();
  const checks = [];

  checks.push({
    id: "demo_scope",
    ok: catalog.demoScope === demoScope.DEMO_SCOPE,
    label: "Knight Logics only scope",
    detail: `demoScope=${catalog.demoScope || "missing"}`,
  });

  checks.push({
    id: "bridge",
    ok: true,
    label: "Local bridge",
    detail: `listening on 127.0.0.1:${PORT}`,
  });

  checks.push({
    id: "python",
    ok: fs.existsSync(PYTHON),
    label: "Poster Python venv",
    detail: fs.existsSync(PYTHON) ? PYTHON : "Missing — run Social-Media-Manager setup",
  });

  checks.push({
    id: "playwright_browsers",
    ok: fs.existsSync(process.env.PLAYWRIGHT_BROWSERS_PATH || PLAYWRIGHT_BROWSERS),
    label: "Playwright browsers",
    detail: process.env.PLAYWRIGHT_BROWSERS_PATH || PLAYWRIGHT_BROWSERS,
  });

  checks.push({
    id: "facebook_mode",
    ok: true,
    label: "Facebook publish mode",
    detail:
      fbMode === "browser_groups"
        ? "Playwright page + community groups (Knight Logics group pool)"
        : "Graph API page only (no groups)",
  });

  let sessionStatus = {};
  if (accountIds.length && fs.existsSync(PYTHON)) {
    try {
      sessionStatus = await runPython(["status", "--accounts", accountIds.join(",")]);
    } catch (err) {
      checks.push({
        id: "session_probe",
        ok: false,
        label: "Session status probe",
        detail: err.message,
      });
    }
  }

  for (const aid of accountIds) {
    const stat = sessionStatus[aid] || {};
    const manifest = demoScope.TARGET_MANIFEST[aid] || { label: aid };
    checks.push({
      id: `account_${aid}`,
      ok: Boolean(stat.session_ready) && !stat.paused,
      label: manifest.label || aid,
      detail: stat.paused
        ? stat.pause_reason || "paused"
        : stat.session_ready
          ? "ready"
          : stat.exists === false
            ? "account missing in poster catalog"
            : "needs Playwright session — Social Poster → Sessions",
      accountId: aid,
      platform: manifest.platform,
    });
  }

  const critical = ["demo_scope", "python", "playwright_browsers"];
  const readyForLiveTest = checks.filter((c) => critical.includes(c.id)).every((c) => c.ok);

  const posterHeaded = ["1", "true", "yes", "on"].includes(
    String(process.env.WS_POSTER_HEADED || "").trim().toLowerCase(),
  );

  return {
    ok: readyForLiveTest,
    readyForLiveTest,
    posterHeaded,
    demoScope: demoScope.DEMO_SCOPE,
    allowedAccounts: demoScope.ALLOWED_DEMO_ACCOUNT_IDS,
    targets: demoScope.buildTargetManifest(accountIds),
    facebookMode: fbMode,
    logPath: LOG_PATH,
    checks,
  };
}

async function handlePlatforms() {
  const catalog = loadPlatforms();
  const accountIds = allDemoAccountIds(catalog);

  let sessionStatus = {};
  if (accountIds.length && fs.existsSync(PYTHON)) {
    try {
      sessionStatus = await runPython(["status", "--accounts", accountIds.join(",")]);
    } catch (err) {
      appendLog("warn", "platform status check failed", { error: err.message });
      sessionStatus = {};
    }
  }

  const platforms = catalog.platforms.map((p) => {
    const ids = accountIdsForPlatform(p);
    const stats = ids.map((id) => sessionStatus[id]).filter(Boolean);
    const readyCount = stats.filter((s) => s.session_ready && !s.paused).length;
    const pausedCount = stats.filter((s) => s.paused).length;
    const playwrightPlatform = PLAYWRIGHT_PLATFORMS.has(p.id);

    let connection = p.status;
    if (!p.posterSupported || !ids.length) connection = "not_wired";
    else if (stats.length && pausedCount === ids.length) connection = "paused";
    else if (readyCount === ids.length) connection = catalog.demoMode ? "demo_ready" : "ready";
    else if (readyCount > 0) connection = catalog.demoMode ? "demo_ready" : "partial";
    else if (playwrightPlatform) connection = "needs_login";
    else connection = "needs_login";

    return {
      ...p,
      connection,
      postingMethod: playwrightPlatform ? "playwright" : p.id === "gbp" ? "api" : p.id === "x" || p.id === "facebook" ? "api" : "mixed",
      sessionReady: readyCount > 0,
      demoAccountCount: ids.length,
      demoAccountsReady: readyCount,
      limitation:
        playwrightPlatform && connection === "needs_login"
          ? "Playwright session on this PC — same Knight Logics Social Poster engine. Open Social Poster → Sessions if needed."
          : p.limitation,
    };
  });

  return {
    ok: true,
    demoMode: catalog.demoMode,
    demoScope: demoScope.DEMO_SCOPE,
    client: catalog.client,
    facebookMode: demoScope.facebookPublishMode(),
    platforms,
    logPath: LOG_PATH,
    gbpLimitations: {
      apiSupported: ["STANDARD", "EVENT", "OFFER"],
      mediaSupported: ["1 still photo per post (PHOTO via public URL)"],
      mediaNotSupported: [
        "video on local posts (use Google dashboard)",
        "animated GIF playback via API",
        "multiple photos per post via API",
        "PRODUCT posts",
      ],
      rateLimit: "10 edits per minute per profile",
      oauthScope: "https://www.googleapis.com/auth/business.manage",
    },
  };
}

function readLogTail(lines = 80) {
  try {
    const raw = fs.readFileSync(LOG_PATH, "utf8");
    return raw.trim().split(/\r?\n/).slice(-lines);
  } catch {
    return [];
  }
}

const server = http.createServer(async (req, res) => {
  cors(res);
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);

  try {
    if (req.method === "GET" && url.pathname === "/health") {
      sendJson(res, 200, {
        ok: true,
        service: "whistle-stop-social-bridge",
        python: fs.existsSync(PYTHON),
        port: PORT,
        logPath: LOG_PATH,
      });
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/preflight") {
      sendJson(res, 200, await handlePreflight());
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/logs") {
      const tail = Number(url.searchParams.get("tail") || 80);
      sendJson(res, 200, { ok: true, logPath: LOG_PATH, lines: readLogTail(tail) });
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/platforms") {
      sendJson(res, 200, await handlePlatforms());
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/history") {
      sendJson(res, 200, { ok: true, history: readJson(HISTORY_PATH, []) });
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/gbp/queue") {
      sendJson(res, 200, { ok: true, queue: readJson(GBP_QUEUE_PATH, []) });
      return;
    }

    if (req.method === "GET" && url.pathname.startsWith("/api/gbp/media/")) {
      const filename = path.basename(url.pathname.slice("/api/gbp/media/".length));
      const filePath = path.join(GBP_MEDIA_DIR, filename);
      if (!filename || !fs.existsSync(filePath)) {
        sendJson(res, 404, { ok: false, error: "Media not found" });
        return;
      }
      const ext = path.extname(filename).toLowerCase();
      const type =
        ext === ".png"
          ? "image/png"
          : ext === ".webp"
            ? "image/webp"
            : ext === ".gif"
              ? "image/gif"
              : "image/jpeg";
      cors(res);
      res.writeHead(200, { "Content-Type": type, "Cache-Control": "public, max-age=3600" });
      fs.createReadStream(filePath).pipe(res);
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/gbp-media/upload") {
      const body = await readBody(req);
      const auth = authorizePost(body, req);
      if (!auth.ok) {
        sendJson(res, 401, { ok: false, error: auth.error });
        return;
      }
      const published = await publishGbpMediaFromBase64(body.mediaBase64 || "");
      if (!published) {
        sendJson(res, 400, { ok: false, error: "GBP media upload requires a still image (JPG, PNG, WebP, or GIF)." });
        return;
      }
      sendJson(res, 200, { ok: true, url: published.url, filename: published.filename });
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/post") {
      const body = await readBody(req);
      const auth = authorizePost(body, req);
      if (!auth.ok) {
        sendJson(res, 401, { ok: false, error: auth.error });
        return;
      }
      delete body.adminPassword;
      sendJson(res, 200, await handlePost(body));
      return;
    }

    sendJson(res, 404, { ok: false, error: "Not found" });
  } catch (err) {
    appendLog("error", "request failed", { error: err.message, path: url.pathname });
    sendJson(res, 500, { ok: false, error: err.message || String(err), logPath: LOG_PATH });
  }
});

server.listen(PORT, "127.0.0.1", () => {
  appendLog("info", "bridge started", {
  port: PORT,
  host: os.hostname(),
  socialRoot: SOCIAL_ROOT,
  playwrightBrowsers: process.env.PLAYWRIGHT_BROWSERS_PATH || PLAYWRIGHT_BROWSERS,
});
  console.log(`Whistle Stop Social Bridge listening on http://127.0.0.1:${PORT}`);
  console.log(`  Health:    http://127.0.0.1:${PORT}/health`);
  console.log(`  Logs:      http://127.0.0.1:${PORT}/api/logs`);
  console.log(`  Log file:  ${LOG_PATH}`);
});
